package com.bww.javabeltexamtwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaBeltExamTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
